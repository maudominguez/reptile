class ObjectSpace (object):

    def __init__(self, nFields):
        self.fields = [None] * nFields
